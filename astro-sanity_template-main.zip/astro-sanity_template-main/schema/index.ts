import blockContent from './blockContent'
import post from './post'

export const schemaTypes = [post, blockContent]
